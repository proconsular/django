from django.apps import AppConfig


class LoginAndRegristrationConfig(AppConfig):
    name = 'login_and_regristration'
