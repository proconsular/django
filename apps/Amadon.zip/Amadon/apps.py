from django.apps import AppConfig


class AmadonConfig(AppConfig):
    name = 'Amadon'
