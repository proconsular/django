from django.apps import AppConfig


class SemiRestfulUsersConfig(AppConfig):
    name = 'semi_restful_users'
